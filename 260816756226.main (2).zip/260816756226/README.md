# 项目部署指南（无需本地安装Git）

## 项目简介
这是一个基于React+TypeScript的现代室内设计网站，展示空间作品集、设计服务和品牌故事。

## 无需Git的部署方案

### 方法一：使用GitHub网页界面直接上传

1. 访问 [GitHub](https://github.com) 并登录您的账号
2. 点击右上角"+"号，选择"New repository"
3. 填写仓库名称（如"interior-design-website"），添加描述，选择"Public"，点击"Create repository"
4. 在新仓库页面，点击"Add file" -> "Upload files"
5. 将本地项目文件夹压缩为ZIP文件
6. 拖拽ZIP文件到GitHub上传区域，或点击"choose your files"选择ZIP文件
7. 滚动到底部，点击"Commit changes"完成上传

### 方法二：Netlify拖放部署

1. 首先在本地构建项目：
   - 打开命令行工具，导航到项目文件夹
   - 运行 `npm install` 安装依赖
   - 运行 `npm run build` 生成dist文件夹

2. 访问 [Netlify](https://www.netlify.com) 并登录您的账号
3. 点击"Add new site" -> "Deploy manually"
4. 将本地生成的"dist"文件夹直接拖拽到页面中央的拖放区域
5. 等待部署完成，Netlify会提供一个临时URL，您可以通过该URL访问您的网站

### 方法三：使用在线代码编辑器（如CodeSandbox）

1. 访问 [CodeSandbox](https://codesandbox.io) 并登录
2. 点击"Create Sandbox" -> "Import Project"
3. 选择"Upload ZIP"并上传您的项目ZIP文件
4. 等待项目加载完成后，点击左侧"Deploy"按钮
5. 选择"Netlify"作为部署目标，按照提示授权并完成部署

## 注意事项
- 方法一和方法三需要您有GitHub账号
- 所有方法都需要您先在本地安装Node.js以运行`npm run build`
- 部署前请确保项目能在本地正常运行