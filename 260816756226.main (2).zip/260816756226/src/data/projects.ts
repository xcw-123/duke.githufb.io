export interface Project {
  id: number;
  title: string;
  location: string;
  category: string;
  mainImageUrl: string;
  hoverImageUrl: string;
}

export const projects: Project[] = [
  {
    id: 1,
    title: "繁花",
    location: "泰州 · 金茂府225精装改造",
    category: "住宅空间",
    mainImageUrl: "https://lf-code-agent.coze.cn/obj/x-ai-cn/260816756226/attachment/4_20250913143448.jpg",
    hoverImageUrl: "https://lf-code-agent.coze.cn/obj/x-ai-cn/260816756226/attachment/6_20250913143601.jpg"
  },
  {
    id: 2,
    title: "红与黑",
    location: "泰州 · 金茂府185精装改造",
    category: "住宅空间",
        mainImageUrl: "https://lf-code-agent.coze.cn/obj/x-ai-cn/260816756226/attachment/√ 餐厅1_output_互动式灯光混合_20250913143718.jpg",
        hoverImageUrl: "https://lf-code-agent.coze.cn/obj/x-ai-cn/260816756226/attachment/2_20250913145959.jpg"
  },
  {
    id: 3,
    title: "家的温度",
    location: "泰州 · 东方小镇",
    category: "住宅空间",
     mainImageUrl: "https://lf-code-agent.coze.cn/obj/x-ai-cn/260816756226/attachment/客厅4_output_互动式灯光混合_20250913150407.jpg",
    hoverImageUrl: "https://lf-code-agent.coze.cn/obj/x-ai-cn/260816756226/attachment/客厅小角度5_output_互动式灯光混合_20250913150528.jpg"
  },
  {
    id: 4,
    title: "太和一古",
    location: "泰兴 · 日料餐厅",
    category: "商业空间",
    mainImageUrl: "https://lf-code-agent.coze.cn/obj/x-ai-cn/260816756226/attachment/7_20250913131846.jpg",
     hoverImageUrl: "https://lf-code-agent.coze.cn/obj/x-ai-cn/260816756226/attachment/19_20250913150658.jpg"
  }
];