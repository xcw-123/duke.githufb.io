import { motion } from 'framer-motion';

// 品牌核心优势数据
const features = [
  {
    title: "匠心工艺",
    description: "我们与顶级工匠合作，精选全球优质材料，注重每一个细节的完美呈现，让精湛工艺成为空间的永恒语言。",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=artisan%20craftsmanship%2Cwoodworking%2Cnatural%20materials%2Cattention%20to%20detail%2Chandmade&sign=82753d88d7b8aa62d62668f7d407ce51"
  },
  {
    title: "科技与舒适",
    description: "将智能科技无缝融入空间设计，通过人性化的细节考量，创造既现代便捷又温暖舒适的生活体验。",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=smart%20home%20technology%2Cinterior%20design%2Ccomfortable%20lighting%2Cmodern%20convenience%2Cwarm%20ambiance&sign=63df4de5fbcfd4a5ed45f6a4a68b2deb"
  },
  {
    title: "定制设计",
    description: "深入理解每位客户的生活方式与审美偏好，提供完全定制化的设计方案，打造真正专属的个性空间。",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=custom%20interior%20design%2Cpersonalized%20space%2Cunique%20furniture%2Ctailored%20details%2Cindividual%20style&sign=88b5b6672e215a7e39de3fd8b2b0fb48"
  },
  {
    title: "可持续理念",
    description: "秉持环保设计理念，优先选择可再生材料与节能系统，在美学与可持续发展之间寻求平衡。",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=sustainable%20interior%20design%2Ceco-friendly%20materials%2Cnatural%20light%2Cindoor%20plants%2Cenergy%20efficiency&sign=d863cd03300b031ae7bc078dc4e81fbf"
  }
];

const FeaturesSection = () => {
  return (
    <section id="features" className="py-24 md:py-32 px-6 md:px-12 bg-white">
      <div className="max-w-7xl mx-auto">
        {/*  section标题 */}
        <div className="text-center mb-16 md:mb-24">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-3xl md:text-4xl font-light tracking-tight mb-4"
          >
            设计理念
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-gray-600 max-w-2xl mx-auto"
          >
            我们相信，卓越的空间设计源于对生活本质的深刻洞察与对美学的不懈追求。
          </motion.p>
        </div>
        
        {/* 核心优势网格 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group"
            >
              {/* 特征图片 */}
              <div className="aspect-square overflow-hidden mb-6">
                <img 
                  src={feature.imageUrl} 
                  alt={feature.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
              </div>
              
              {/* 特征标题和描述 */}
              <h3 className="text-xl font-light mb-3 group-hover:text-gray-600 transition-colors">{feature.title}</h3>
              <p className="text-gray-600 text-sm leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;