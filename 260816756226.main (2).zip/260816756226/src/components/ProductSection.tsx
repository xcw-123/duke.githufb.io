import { motion } from "framer-motion";
import { useState } from "react";
import { projects } from "@/data/projects";

const ProductSection = () => {
    const [activeCategory, setActiveCategory] = useState("全部");
    const filteredProjects = activeCategory === "全部" ? projects : projects.filter(project => project.category === activeCategory);

    return (
        <section id="projects" className="py-24 md:py-32 px-6 md:px-12 bg-gray-50">
            <div className="max-w-7xl mx-auto">
                {}
                <div className="text-center mb-16 md:mb-24">
                    <motion.h2
                        initial={{
                            opacity: 0,
                            y: 20
                        }}
                        whileInView={{
                            opacity: 1,
                            y: 0
                        }}
                        viewport={{
                            once: true
                        }}
                        transition={{
                            duration: 0.8
                        }}
                        className="text-3xl md:text-4xl font-light tracking-tight mb-4"
                        style={{
                            fontWeight: "bold"
                        }}>空间作品集
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  </motion.h2>
                    <motion.p
                        initial={{
                            opacity: 0,
                            y: 20
                        }}
                        whileInView={{
                            opacity: 1,
                            y: 0
                        }}
                        viewport={{
                            once: true
                        }}
                        transition={{
                            duration: 0.8,
                            delay: 0.2
                        }}
                        className="text-gray-600 max-w-2xl mx-auto">每一个空间作品，都是我们对生活美学的独特诠释，融合东方智慧与现代设计语言，创造兼具功能性与艺术性的理想环境。
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  </motion.p>
                </div>
                {}
                <div className="flex justify-center space-x-8 mb-12">
                    {["全部", "住宅空间", "商业空间"].map(category => <button
                        key={category}
                        onClick={() => setActiveCategory(category)}
                        className={`text-sm tracking-wide transition-colors ${activeCategory === category ? "text-black border-b-2 border-black pb-1" : "text-gray-500 hover:text-gray-800 pb-1 border-b-2 border-transparent"}`}
                        style={{
                            fontWeight: "bold"
                        }}>
                        {category}
                    </button>)}
                </div>
                {}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
                    {filteredProjects.map((project, index) => <motion.div
                        key={project.id}
                        initial={{
                            opacity: 0,
                            y: 30
                        }}
                        whileInView={{
                            opacity: 1,
                            y: 0
                        }}
                        viewport={{
                            once: true
                        }}
                        transition={{
                            duration: 0.6,
                            delay: index * 0.1
                        }}
                        className="group relative overflow-hidden cursor-pointer">
                        {}
                        <div className="aspect-[4/3] overflow-hidden">
                            <img src={project.mainImageUrl} alt="" className="w-full h-full object-cover" />
                        </div>
                        {}
                         <div
                            className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6"
                            style={{
                                backgroundImage: `url(${project.hoverImageUrl})`,
                                backgroundSize: "cover",
                                backgroundRepeat: "no-repeat",
                                backgroundPosition: "50% 50%",
                                backgroundColor: "#FFFFFF"
                            }}>
                            <h3
                                className="text-white text-xl font-light mb-1"
                                style={{
                                    fontWeight: "bold"
                                }}>{project.title}</h3>
                            <p className="text-white/80 text-sm mb-3">{project.location}</p>
                            <span className="text-white/70 text-xs tracking-wider">{project.category}</span>
                        </div>
                    </motion.div>)}
                </div>
                <div className="text-center mt-16">
                    <motion.button
                        whileHover={{
                            scale: 1.02
                        }}
                        whileTap={{
                            scale: 0.98
                        }}
                        className="px-8 py-3 border border-gray-900 text-sm tracking-wide hover:bg-gray-900 hover:text-white transition-colors duration-300">查看全部项目
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  </motion.button>
                </div>
            </div>
        </section>
    );
};

export default ProductSection;