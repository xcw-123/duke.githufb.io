import { motion } from "framer-motion";
import { useEffect, useState } from "react";

const HeroBanner = () => {
    const [isLoaded, setIsLoaded] = useState(false);

    useEffect(() => {
        const img = new Image();
        img.src = "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=modern%20minimalist%20interior%20design%2Cliving%20room%20with%20natural%20light%2Chigh-end%20materials%2Celegant%20atmosphere%2Cwarm%20tones%2CChinese%20design%20elements&sign=93db1a876c617306604d78fca5f038ce";
        img.onload = () => setIsLoaded(true);
    }, []);

    return (
        <section className="relative h-screen overflow-hidden">
            {}
            <div
                className={`absolute inset-0 w-full h-full transition-opacity duration-1000 ${isLoaded ? "opacity-100" : "opacity-0"}`}>
                <img
                    src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=modern%20minimalist%20interior%20design%2Cliving%20room%20with%20natural%20light%2Chigh-end%20materials%2Celegant%20atmosphere%2Cwarm%20tones%2CChinese%20design%20elements&sign=93db1a876c617306604d78fca5f038ce"
                    alt="现代极简主义室内设计"
                    className="w-full h-full object-cover object-center" />
                <div className="absolute inset-0 bg-black/10"></div>
            </div>
            {}
            <div
                className="relative h-full flex flex-col justify-center items-center text-center px-4"
                style={{
                    backgroundImage: "url(https://space-static.coze.cn/coze_space/7549384331178754313/upload/%E5%AE%A2%E5%8E%853_output_%E4%BA%92%E5%8A%A8%E5%BC%8F%E7%81%AF%E5%85%89%E6%B7%B7%E5%90%88_4190x2793.jpg?sign=1760321775-f40f6369f6-0-0833b3b9ebea23f04e0552c744c152fd6a0f169c8e913796ebd9f0fb8d70bea4)",
                    backgroundSize: "cover",
                    backgroundRepeat: "no-repeat",
                    backgroundPosition: "50% 50%"
                }}>
                <motion.h1
                    initial={{
                        opacity: 0,
                        y: 20
                    }}
                    animate={{
                        opacity: 1,
                        y: 0
                    }}
                    transition={{
                        duration: 0.8,
                        delay: 0.3
                    }}
                    className="text-4xl md:text-6xl font-light tracking-tight text-white mb-6 max-w-3xl">以设计赋予空间价值<br />以设计定义生活美学
                            </motion.h1>
                <motion.p
                    initial={{
                        opacity: 0,
                        y: 20
                    }}
                    animate={{
                        opacity: 1,
                        y: 0
                    }}
                    transition={{
                        duration: 0.8,
                        delay: 0.6
                    }}
                    className="text-lg md:text-xl font-light text-white/90 mb-10 max-w-2xl">融合东方意境与现代美学，为您打造兼具温度与深度的生活空间
                            </motion.p>
                <motion.div
                    initial={{
                        opacity: 0,
                        y: 20
                    }}
                    animate={{
                        opacity: 1,
                        y: 0
                    }}
                    transition={{
                        duration: 0.8,
                        delay: 0.9
                    }}>
                    <a
                        href="#projects"
                        className="inline-block px-8 py-3 border border-white text-white text-sm tracking-wide hover:bg-white hover:text-gray-900 transition-colors duration-300">探索案例
                                  </a>
                </motion.div>
            </div>
            {}
             <motion.div
                animate={{
                    y: [0, 10, 0]
                }}
                transition={{
                    repeat: Infinity,
                    duration: 2,
                    ease: "easeInOut"
                }}
                whileHover={{ 
                    scale: 1.2,
                    opacity: 1
                }}
                whileTap={{ 
                    scale: 0.9
                }}
                className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white/80 cursor-pointer transition-all duration-300 hover:opacity-100"
                onClick={() => {
                    // 平滑滚动到空间作品集区域
                    const projectsSection = document.getElementById("projects");
                    if (projectsSection) {
                        // 添加额外的偏移量以考虑固定导航栏
                        const navbarHeight = document.querySelector('header')?.offsetHeight || 0;
                        const targetPosition = projectsSection.getBoundingClientRect().top + window.pageYOffset - navbarHeight;
                        
                        window.scrollTo({
                            top: targetPosition,
                            behavior: 'smooth'
                        });
                    }
                }}
                aria-label="滚动到作品集"
            >
                <i class="fa-solid fa-chevron-down text-sm"></i>
            </motion.div>
        </section>
    );
};

export default HeroBanner;