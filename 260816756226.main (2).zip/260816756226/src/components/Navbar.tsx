import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface NavbarProps {
    scrolled: boolean;
}

const Navbar = (
    {
        scrolled
    }: NavbarProps
) => {
    return (
        <header
            className={cn(
                "fixed top-0 left-0 right-0 z-50 transition-all duration-500 ease-in-out px-6 md:px-12",
                scrolled ? "bg-white/95 backdrop-blur-sm shadow-sm py-3" : "bg-transparent py-6"
            )}>
            <div className="max-w-7xl mx-auto flex items-center justify-between">
                {}
                <motion.div
                    initial={{
                        opacity: 0,
                        y: -10
                    }}
                    animate={{
                        opacity: 1,
                        y: 0
                    }}
                    transition={{
                        duration: 0.5
                    }}>
                     <a href="/" className="text-2xl font-light tracking-wider">
  <img src="https://lf-code-agent.coze.cn/obj/x-ai-cn/260816756226/attachment/微信图片_20221219110546_20250913100852.png" alt="度克设计" className="h-8 w-auto" />
</a>
                </motion.div>
                {}
                <nav className="hidden md:flex items-center space-x-10">
                    <a
                        href="#projects"
                        className="text-sm tracking-wide hover:text-gray-600 transition-colors">项目案例</a>
                    <a
                        href="#services"
                        className="text-sm tracking-wide hover:text-gray-600 transition-colors">设计服务</a>
                    <a
                        href="#story"
                        className="text-sm tracking-wide hover:text-gray-600 transition-colors">品牌故事</a>
                    <a
                        href="#process"
                        className="text-sm tracking-wide hover:text-gray-600 transition-colors">设计流程</a>
                </nav>
                {}

                {}
                <button className="md:hidden text-gray-900">
                    <i class="fa-solid fa-bars text-xl"></i>
                </button>
            </div>
        </header>
    );
};

export default Navbar;